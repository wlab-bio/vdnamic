import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial import procrustes

def decode_indices_vectorized(strings, digits="ACGT"):
    """Vectorized decoding of base4 strings to integer indices."""
    lut = {ch: i for i, ch in enumerate(digits)}
    indices = np.zeros(len(strings), dtype=np.int64)
    for i, s in enumerate(strings):
        s = s.strip().upper()
        if not s:
            indices[i] = -1
        else:
            n = 0
            for ch in s:
                if ch in lut:
                    n = (n << 2) + lut[ch]
            indices[i] = n
    return indices

# Load data
coords = np.loadtxt('sim_fastq/uei/uei_grp0/final_coords.txt', delimiter=',')
labels_data = np.loadtxt('sim_fastq/uei/uei_grp0/final_labels.txt', delimiter=',', dtype=str)
pos_data = np.loadtxt('pos.csv', delimiter=',')

# Decode base4 strings from column 10 of labels to get row indices
indices = decode_indices_vectorized(labels_data[:, 9] if labels_data.ndim > 1 else labels_data)

# Create masks
valid_mask = (indices >= 0) & (indices < pos_data.shape[0])
n_blank = np.sum(indices == -1)
if n_blank > 0:
    print(f"Info: {n_blank} blank entries found")

# Extract color values from pos.csv column 3
color_values = np.full(len(indices), np.nan)
color_values[valid_mask] = pos_data[indices[valid_mask], 2]

# Extract corresponding pos.csv coordinates (columns 3,4 -> indices 2,3)
pos_coords_for_final = np.full((len(indices), 2), np.nan)
pos_coords_for_final[valid_mask] = pos_data[indices[valid_mask], 2:4]

# Procrustes transformation on valid points only
final_coords_valid = coords[valid_mask, :2]
pos_coords_valid = pos_coords_for_final[valid_mask]
mtx1, mtx2_transformed, disparity = procrustes(final_coords_valid, pos_coords_valid)

# Reconstruct transformation parameters
pos_mean = np.mean(pos_coords_valid, axis=0)
final_mean = np.mean(final_coords_valid, axis=0)
pos_centered = pos_coords_valid - pos_mean
final_centered = final_coords_valid - final_mean
pos_scale = np.sqrt(np.sum(pos_centered**2))
final_scale = np.sqrt(np.sum(final_centered**2))
scale = final_scale / pos_scale if pos_scale > 0 else 1.0

# Find rotation/reflection matrix
U, _, Vt = np.linalg.svd((pos_centered / pos_scale).T @ (final_centered / final_scale))
R = U @ Vt

# Apply transformation to all pos.csv points
pos_all_transformed = scale * (pos_data[:, 2:4] - pos_mean) @ R + final_mean
pos_coords_transformed = np.full((len(indices), 2), np.nan)
pos_coords_transformed[valid_mask] = scale * (pos_coords_for_final[valid_mask] - pos_mean) @ R + final_mean

# Create figure with two panels
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(18, 8))
vmin, vmax = np.nanmin(color_values), np.nanmax(color_values)

# Left panel: Transformed pos.csv coordinates
ax1.scatter(pos_all_transformed[:, 0], pos_all_transformed[:, 1], 
           c='lightgray', s=5, alpha=0.2, zorder=1)
scatter1 = ax1.scatter(pos_coords_transformed[:, 0], pos_coords_transformed[:, 1], 
                       c=color_values, cmap='viridis', s=2, alpha=0.7,
                       edgecolors='black', linewidth=0.5,
                       vmin=vmin, vmax=vmax, zorder=2)
ax1.set(xlabel='X Coordinate', ylabel='Y Coordinate',
        title='pos.csv Coordinates\n(Procrustes-aligned to final_coords)')
ax1.grid(True, alpha=0.3, linestyle='--')
ax1.set_aspect('equal', adjustable='box')

# Right panel: Original final_coords
scatter2 = ax2.scatter(coords[:, 0], coords[:, 1], 
                      c=color_values, cmap='viridis', s=2, alpha=0.7,
                      edgecolors='black', linewidth=0.5,
                      vmin=vmin, vmax=vmax, zorder=2)
ax2.set(xlabel='X Coordinate', ylabel='Y Coordinate',
        title='final_coords.txt Coordinates\nColored by pos.csv Values')
ax2.grid(True, alpha=0.3, linestyle='--')
ax2.set_aspect('equal', adjustable='box')

# Add colorbar without overlap
fig.subplots_adjust(right=0.85)
cbar_ax = fig.add_axes([0.88, 0.15, 0.02, 0.7])
cbar = fig.colorbar(scatter2, cax=cbar_ax, label='Value from pos.csv (column 3)')

# Statistics
print(f"\n=== Statistics ===")
print(f"Points: {len(coords)} total, {np.sum(valid_mask)} mapped")
print(f"Color range: [{vmin:.3f}, {vmax:.3f}]")
print(f"Procrustes disparity: {disparity:.6f}")
print(f"Scale factor: {scale:.3f}, Reflection: {'Yes' if np.linalg.det(R) < 0 else 'No'}")

if disparity < 0.05:
    print("TESTS PASSED.")
else:
    print("TESTS FAILED: disparity = " + str(disparity))

plt.suptitle('Correspondence between pos.csv and final_coords.txt', fontsize=16, y=0.98)
plt.savefig('scatter_plot_with_procrustes.png', dpi=300, bbox_inches='tight')
print("\nSaved as 'scatter_plot_with_procrustes.png'")
