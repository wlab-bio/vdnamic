import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable

def decode_index_base4(s: str, digits: str = "ACGT") -> int:
    """Inverse of encode_index_base4 / encode_indices_base4_vectorized."""
    s = s.strip().upper()
    lut = {ch: i for i, ch in enumerate(digits)}
    n = 0
    for ch in s:
        if ch not in lut:
            raise ValueError(f"invalid digit {ch!r} for digits={digits!r}")
        n = (n << 2) + lut[ch]  # multiply by 4, add digit
    return n

# Vectorized version of decode_index_base4 for efficiency
def decode_indices_vectorized(strings, digits="ACGT"):
    """Vectorized decoding of base4 strings to integer indices.
    Returns -1 for empty/blank strings."""
    # Create lookup table
    lut = {ch: i for i, ch in enumerate(digits)}
    
    # Process all strings
    indices = np.zeros(len(strings), dtype=np.int64)
    for i, s in enumerate(strings):
        s = s.strip().upper()
        if not s:  # Handle empty strings
            indices[i] = -1
        else:
            n = 0
            for ch in s:
                if ch in lut:
                    n = (n << 2) + lut[ch]
            indices[i] = n
    return indices

# Load coordinates
coords = np.loadtxt('sim_fastq/uei/uei_grp0/final_coords.txt', delimiter=',')
n_samples, n_dims = coords.shape

# Load labels and extract 10th column (index 9)
labels_data = np.loadtxt('sim_fastq/uei/uei_grp0/final_labels.txt', delimiter=',', dtype=str)
base4_strings = labels_data[:, 9] if labels_data.ndim > 1 else labels_data

# Decode base4 strings to integer indices
indices = decode_indices_vectorized(base4_strings)

# Load pos.csv and create lookup for 3rd column values
# Note: Using regular delimiter (assuming comma or tab/space)
pos_data = np.loadtxt('pos.csv', delimiter=',')
max_index = pos_data.shape[0]

# Initialize color values with NaN for invalid/blank entries
color_values = np.full(len(indices), np.nan)

# Create masks for valid and blank entries
blank_mask = indices == -1
valid_mask = (indices >= 0) & (indices < max_index)

# Report statistics
n_blank = np.sum(blank_mask)
n_out_of_bounds = np.sum((indices >= max_index))
if n_blank > 0:
    print(f"Info: {n_blank} blank entries found, will appear as unfilled points")
if n_out_of_bounds > 0:
    print(f"Warning: {n_out_of_bounds} indices out of bounds")

# Extract float values from 3rd column (index 2) using integer indices
# Only for valid indices (non-blank and within bounds)
color_values[valid_mask] = pos_data[indices[valid_mask], 2]

# Create 2D scatter plot (using first 2 dimensions if 3D)
fig, ax = plt.subplots(1, 1, figsize=(10, 8))

# Create scatter plot with color mapping
scatter = ax.scatter(coords[:, 0], coords[:, 1], 
                    c=color_values, 
                    cmap='viridis',
                    s=20,
                    alpha=0.7,
                    edgecolors='black',
                    linewidth=0.5)

# Add colorbar
cbar = plt.colorbar(scatter, ax=ax, label='Value from pos.csv')

# Set labels and title
ax.set_xlabel('X Coordinate', fontsize=12)
ax.set_ylabel('Y Coordinate', fontsize=12)
ax.set_title('2D Scatter Plot of Coordinates\nColored by pos.csv Values', fontsize=14)

# Add grid for better readability
ax.grid(True, alpha=0.3, linestyle='--')

# Set aspect ratio to equal for undistorted view
ax.set_aspect('equal', adjustable='box')

# Display statistics
print(f"Number of points: {n_samples}")
print(f"Coordinate dimensions: {n_dims}")
valid_colors = color_values[~np.isnan(color_values)]
if len(valid_colors) > 0:
    print(f"Color value range: [{valid_colors.min():.3f}, {valid_colors.max():.3f}]")
    print(f"Mean color value: {valid_colors.mean():.3f}")
    print(f"Std color value: {valid_colors.std():.3f}")
print(f"Points with valid colors: {len(valid_colors)}/{n_samples}")

plt.tight_layout()
plt.savefig('scatter_plot.png', dpi=300, bbox_inches='tight')
print("Saved scatter plot as 'scatter_plot.png'")
plt.close()


